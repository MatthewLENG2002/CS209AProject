package sustc.cs209.github.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import sustc.cs209.github.dao.entity.Release;

public interface ReleaseMapper extends BaseMapper<Release> {

}
