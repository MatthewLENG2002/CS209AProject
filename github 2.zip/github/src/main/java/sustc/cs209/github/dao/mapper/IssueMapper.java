package sustc.cs209.github.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import sustc.cs209.github.dao.entity.Issue;

public interface IssueMapper extends BaseMapper<Issue> {

}
