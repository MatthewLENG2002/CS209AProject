package sustc.cs209.github.dao.mapper;

import com.baomidou.mybatisplus.test.autoconfigure.MybatisPlusTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThat;

@MybatisPlusTest
class RepositoryMapperTest {

    @Autowired
    RepositoryMapper repositoryMapper;

    @Test
    void testSimpleInsert() {
        assertThat(1).isLessThan(2);
    }
}
