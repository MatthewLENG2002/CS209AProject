package sustc.cs209.github.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import sustc.cs209.github.dao.entity.*;
import sustc.cs209.github.dao.mapper.RepositoryMapper;
import sustc.cs209.github.dao.mapper.UserMapper;
import sustc.cs209.github.dto.CommitsStat;
import sustc.cs209.github.dto.IssueResolutionDTO;
import sustc.cs209.github.dto.ReleaseStat;
import sustc.cs209.github.service.RepositoryService;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

@Service
public class RepositoryServiceImpl implements RepositoryService {

    @Autowired
    private RepositoryMapper repositoryMapper;

    @Autowired
    private UserMapper userMapper;

    public int getOpenIssueCount(Integer id) {
        List<Issue> issues = repositoryMapper.getIssues(id);
        int count = 0;
        for (Issue issue : issues) {
            if (issue.getClosed().equals(Boolean.FALSE)) {
                count++;
            }
        }
        return count;
    }

    public int getClosedIssueCount(Integer id) {
        List<Issue> issues = repositoryMapper.getIssues(id);
        int count = 0;
        for (Issue issue : issues) {
            if (issue.getClosed().equals(Boolean.TRUE)) {
                count++;
            }
        }
        return count;
    }

    public int getReleaseCount(Integer id) {
        return repositoryMapper.getReleases(id).size();
    }

    public List<Entry<User, Integer>> getTopCommitter(Integer id) {
        List<Commit> commits = repositoryMapper.getCommits(id);
        List<User> users = repositoryMapper.getContributors(id);
        Map<User, Integer> commitCount = new HashMap<>();
        for (User user : users) {
            commitCount.put(user, 0);
        }
        for (Commit commit : commits) {
            User usr = userMapper.getUserByLogin(commit.getAuthor());
            commitCount.put(usr, commitCount.get(usr) + 1);
        }
        List<Entry<User, Integer>> res = new ArrayList<Entry<User, Integer>>(commitCount.entrySet());
        Collections.sort(res,new Comparator<Entry<User,Integer>>() {
            public int compare(Entry<User, Integer> o1, Entry<User, Integer> o2) {
                return o1.getValue()-o2.getValue();
            }
        });
        return res.subList(0, 10);
    }

    public IssueResolutionDTO getIssueResolution(Integer id) {
        List<Issue> issues = repositoryMapper.getIssues(id);
        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (Issue issue : issues) {
            if (issue.getClosed().equals(Boolean.TRUE)) {
                Long dur = issue.getDuration();
                if (dur != -1) {
                    stats.addValue(dur);
                }
            }
        }
        IssueResolutionDTO dto = new IssueResolutionDTO(stats.getMin(), stats.getMax(), stats.getMean(), stats.getPercentile(50), stats.getPercentile(25), stats.getPercentile(75), stats.getStandardDeviation());
        return dto;
    }

    public List<ReleaseStat> getReleaseStats(Integer id) {
        List<Release> releases = repositoryMapper.getReleases(id);
        if (releases.size() == 0) {
            return new ArrayList<ReleaseStat>();
        }
        List<Commit> commits = repositoryMapper.getCommits(id);
        List<ReleaseStat> res = new ArrayList<>();
        res.add(new ReleaseStat(releases.get(0).getTag_name(), -1L, releases.get(0).getPublished_at(), 0));
        for (int i = 1; i < releases.size(); i++) {
            res.add(new ReleaseStat(releases.get(i).getTag_name(), releases.get(i).getPublished_at()));
            res.get(i).setStart(res.get(i - 1).getEnd());
        }
        res.add(new ReleaseStat("Latest", res.get(res.size() - 1).getEnd(), new Date().getTime(), 0));
        commits.sort(new Comparator<Commit>() {
            public int compare(Commit o1, Commit o2) {
                return o1.getCommit_date().compareTo(o2.getCommit_date());
            }
        });
        for (Commit commit : commits) {
            for (int i = 0; i < res.size(); i++) {
                if (commit.getCommit_date() >= res.get(i).getStart() && commit.getCommit_date() <= res.get(i).getEnd()) {
                    res.get(i).setCommits(res.get(i).getCommits() + 1);
                }
            }
        }
        return res;
    }

    public CommitsStat getCommitsStats(Integer id) {
        Integer[][] stats = new Integer[7][24];
        List<Commit> commits = repositoryMapper.getCommits(id);
        for (int i = 0; i < commits.size(); i++) {
            Date date = new Date(commits.get(i).getCommit_date());
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            stats[cal.get(Calendar.DAY_OF_WEEK) - 1][cal.get(Calendar.HOUR_OF_DAY)]++;
        }
        return new CommitsStat(stats);
    }



}
