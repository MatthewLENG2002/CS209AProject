package sustc.cs209.github.dao.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@ToString
@TableName("t_ds_commit")
public class Commit {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("sha")
    private String sha;

    @TableField("repo")
    private Integer repoId;

    @TableField("html")
    private String html_url;

    @TableField("author")
    private String author;

    @TableField("commit_at")
    private Long commit_date;

}
