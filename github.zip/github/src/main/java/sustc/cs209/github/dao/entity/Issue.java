package sustc.cs209.github.dao.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@ToString
@TableName("t_ds_issue")
public class Issue {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @TableField("repo")
    private Integer repoId;

    @TableField("display")
    private Integer display;

    @TableField("title")
    private String title;

    @TableField("description")
    private String description;

    @TableField("comments")
    private String comments;

    @TableField("closed")
    private Boolean closed;

    @TableField("create")
    private Long created_at;

    @TableField("close")
    private Long closed_at;

    public Long getDuration() {
        if (closed)
            return closed_at - created_at;
        else
            return -1L;
    }
}
