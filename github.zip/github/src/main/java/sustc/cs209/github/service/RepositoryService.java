package sustc.cs209.github.service;

import org.springframework.stereotype.Service;

@Service
public interface RepositoryService {

}
