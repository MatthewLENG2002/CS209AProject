package sustc.cs209.github.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class IssueResolutionDTO {

    Double minTime;
    Double maxTime;
    Double avgTime;
    Double medianTime;
    Double Q1Time;
    Double Q3Time;
    Double varTime;

}
