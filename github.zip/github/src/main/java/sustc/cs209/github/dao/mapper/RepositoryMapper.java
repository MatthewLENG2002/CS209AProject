package sustc.cs209.github.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import sustc.cs209.github.dao.entity.*;

import java.util.List;

@Mapper
public interface RepositoryMapper extends BaseMapper<Repository> {

    /**
     * Get available repositories.
     *
     */
    List<Repository> getRepos();

    /**
     * Get contributors of a repository.
     * @param id repository id
     */
    List<User> getContributors(@Param("id") Integer id);

    /**
     * Get issues of a repository.
     * @param id repository id
     */
    List<Issue> getIssues(@Param("id") Integer id);

    /**
     * Get commits of a repository.
     * @param id repository id
     */
    List<Commit> getCommits(@Param("id") Integer id);

    /**
     * Get releases of a repository.
     * @param id repository id
     */
    List<Release> getReleases(@Param("id") Integer id);

}
