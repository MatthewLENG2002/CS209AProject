package util;

public class GithubApiRequest {
}
